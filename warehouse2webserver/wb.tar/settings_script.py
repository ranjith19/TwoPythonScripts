HOST="localhost"
UNAME='pearlwhite85'
PWD='eekthecat85'

#connection_string="host="+"'"+host+"',"+"user="+"'"+UNAME+"',"+ "password="+"'"+PWD+"'"
connection_string="host='%s',user='%s',passwd='%s'"%(HOST,UNAME,PWD)



	